import { Canvas } from "@react-three/fiber";
import { Suspense } from "react";
import "@fontsource/inter";
import { Lights } from "./components/Lights";
import { CameraController } from "./components/CameraController";
import { Targets } from "./components/Targets";
import { ClickHandler } from "./components/ClickHandler";
import { HUD } from "./components/HUD";
import { MapSelector } from "./components/MapSelector";

function App() {
  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      <Canvas
        camera={{
          position: [0, 5, 0],
          fov: 75,
          near: 0.1,
          far: 1000
        }}
        gl={{
          antialias: true,
          powerPreference: "high-performance"
        }}
      >
        <color attach="background" args={["#1a1a1a"]} />
        
        <Lights />
        
        <Suspense fallback={null}>
          <MapSelector />
          <Targets />
        </Suspense>
        
        <CameraController />
        <ClickHandler />
      </Canvas>
      
      <HUD />
    </div>
  );
}

export default App;
