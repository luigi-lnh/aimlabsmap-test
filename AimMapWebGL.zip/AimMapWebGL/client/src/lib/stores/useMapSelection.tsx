import { create } from "zustand";

export type MapType = "classic" | "platforms" | "arena";

interface MapSelectionState {
  currentMap: MapType;
  setMap: (map: MapType) => void;
}

export const useMapSelection = create<MapSelectionState>((set) => ({
  currentMap: "classic",
  setMap: (map) => {
    set({ currentMap: map });
    console.log(`Switched to map: ${map}`);
  }
}));
