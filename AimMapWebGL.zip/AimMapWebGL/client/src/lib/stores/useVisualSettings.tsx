import { create } from "zustand";

export type Theme = "default" | "neon" | "sunset" | "ocean";

interface VisualSettingsState {
  theme: Theme;
  fov: number;
  
  setTheme: (theme: Theme) => void;
  setFov: (fov: number) => void;
  increaseFov: () => void;
  decreaseFov: () => void;
}

export const useVisualSettings = create<VisualSettingsState>((set) => ({
  theme: "default",
  fov: 75,
  
  setTheme: (theme) => {
    set({ theme });
    console.log(`Theme changed to: ${theme}`);
  },
  
  setFov: (fov) => {
    const clampedFov = Math.max(50, Math.min(110, fov));
    set({ fov: clampedFov });
    console.log(`FOV set to: ${clampedFov}`);
  },
  
  increaseFov: () => {
    set((state) => {
      const newFov = Math.min(110, state.fov + 5);
      console.log(`FOV increased to: ${newFov}`);
      return { fov: newFov };
    });
  },
  
  decreaseFov: () => {
    set((state) => {
      const newFov = Math.max(50, state.fov - 5);
      console.log(`FOV decreased to: ${newFov}`);
      return { fov: newFov };
    });
  }
}));
