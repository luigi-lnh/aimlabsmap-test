import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export interface Target {
  id: string;
  position: [number, number, number];
  spawnTime: number;
}

interface AimTrainingState {
  targets: Target[];
  score: number;
  shots: number;
  hits: number;
  startTime: number | null;
  isActive: boolean;
  
  // Actions
  startSession: () => void;
  endSession: () => void;
  addTarget: (target: Target) => void;
  removeTarget: (id: string) => void;
  recordShot: () => void;
  recordHit: () => void;
  reset: () => void;
}

export const useAimTraining = create<AimTrainingState>()(
  subscribeWithSelector((set, get) => ({
    targets: [],
    score: 0,
    shots: 0,
    hits: 0,
    startTime: null,
    isActive: false,
    
    startSession: () => {
      set({
        isActive: true,
        startTime: Date.now(),
        score: 0,
        shots: 0,
        hits: 0,
        targets: []
      });
      console.log("Training session started");
    },
    
    endSession: () => {
      set({ isActive: false });
      console.log("Training session ended");
    },
    
    addTarget: (target) => {
      set((state) => ({
        targets: [...state.targets, target]
      }));
    },
    
    removeTarget: (id) => {
      set((state) => ({
        targets: state.targets.filter((t) => t.id !== id)
      }));
    },
    
    recordShot: () => {
      set((state) => ({
        shots: state.shots + 1
      }));
    },
    
    recordHit: () => {
      set((state) => ({
        hits: state.hits + 1,
        score: state.score + 100
      }));
    },
    
    reset: () => {
      set({
        targets: [],
        score: 0,
        shots: 0,
        hits: 0,
        startTime: null,
        isActive: false
      });
    }
  }))
);
