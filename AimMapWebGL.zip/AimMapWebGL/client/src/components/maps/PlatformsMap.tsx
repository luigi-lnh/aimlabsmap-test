import * as THREE from "three";

export function PlatformsMap() {
  return (
    <group>
      {/* Main floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[50, 50]} />
        <meshStandardMaterial color="#1a2a3a" roughness={0.8} metalness={0.2} />
      </mesh>

      {/* Grid lines */}
      <gridHelper args={[50, 50, '#2a3a4a', '#2a3a4a']} position={[0, 0.01, 0]} />

      {/* Multiple floating platforms at various heights */}
      <mesh position={[-8, 1.5, -8]} castShadow receiveShadow>
        <boxGeometry args={[5, 0.5, 5]} />
        <meshStandardMaterial color="#4a5a6a" roughness={0.7} metalness={0.3} />
      </mesh>

      <mesh position={[8, 2.5, -8]} castShadow receiveShadow>
        <boxGeometry args={[4, 0.5, 4]} />
        <meshStandardMaterial color="#5a6a7a" roughness={0.7} metalness={0.3} />
      </mesh>

      <mesh position={[-8, 3.5, 8]} castShadow receiveShadow>
        <boxGeometry args={[4, 0.5, 4]} />
        <meshStandardMaterial color="#5a6a7a" roughness={0.7} metalness={0.3} />
      </mesh>

      <mesh position={[8, 1.5, 8]} castShadow receiveShadow>
        <boxGeometry args={[5, 0.5, 5]} />
        <meshStandardMaterial color="#4a5a6a" roughness={0.7} metalness={0.3} />
      </mesh>

      {/* Center elevated platform */}
      <mesh position={[0, 4, 0]} castShadow receiveShadow>
        <boxGeometry args={[6, 0.5, 6]} />
        <meshStandardMaterial color="#6a7a8a" roughness={0.7} metalness={0.3} />
      </mesh>

      {/* Stepped platforms */}
      <mesh position={[-4, 0.75, 0]} castShadow receiveShadow>
        <boxGeometry args={[3, 1.5, 8]} />
        <meshStandardMaterial color="#3a4a5a" roughness={0.7} metalness={0.3} />
      </mesh>

      <mesh position={[4, 0.75, 0]} castShadow receiveShadow>
        <boxGeometry args={[3, 1.5, 8]} />
        <meshStandardMaterial color="#3a4a5a" roughness={0.7} metalness={0.3} />
      </mesh>

      {/* High platforms */}
      <mesh position={[0, 5.5, -10]} castShadow receiveShadow>
        <boxGeometry args={[4, 0.5, 4]} />
        <meshStandardMaterial color="#7a8a9a" roughness={0.7} metalness={0.3} />
      </mesh>

      <mesh position={[0, 5.5, 10]} castShadow receiveShadow>
        <boxGeometry args={[4, 0.5, 4]} />
        <meshStandardMaterial color="#7a8a9a" roughness={0.7} metalness={0.3} />
      </mesh>

      {/* Boundary walls */}
      <mesh position={[0, 5, -15]} castShadow receiveShadow>
        <boxGeometry args={[30, 10, 1]} />
        <meshStandardMaterial color="#2a3a4a" roughness={0.8} metalness={0.2} />
      </mesh>

      <mesh position={[0, 5, 15]} castShadow receiveShadow>
        <boxGeometry args={[30, 10, 1]} />
        <meshStandardMaterial color="#2a3a4a" roughness={0.8} metalness={0.2} />
      </mesh>

      <mesh position={[-15, 5, 0]} castShadow receiveShadow>
        <boxGeometry args={[1, 10, 30]} />
        <meshStandardMaterial color="#2a3a4a" roughness={0.8} metalness={0.2} />
      </mesh>

      <mesh position={[15, 5, 0]} castShadow receiveShadow>
        <boxGeometry args={[1, 10, 30]} />
        <meshStandardMaterial color="#2a3a4a" roughness={0.8} metalness={0.2} />
      </mesh>
    </group>
  );
}
