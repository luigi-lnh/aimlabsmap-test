import * as THREE from "three";

export function ClassicMap() {
  return (
    <group>
      {/* Main floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[50, 50]} />
        <meshStandardMaterial color="#2a2a2a" roughness={0.8} metalness={0.2} />
      </mesh>

      {/* Grid lines */}
      <gridHelper args={[50, 50, '#3a3a3a', '#3a3a3a']} position={[0, 0.01, 0]} />

      {/* Center platform */}
      <mesh position={[0, 0.5, 0]} castShadow receiveShadow>
        <boxGeometry args={[4, 1, 4]} />
        <meshStandardMaterial color="#4a4a4a" roughness={0.7} metalness={0.3} />
      </mesh>

      {/* Cardinal direction platforms */}
      <mesh position={[0, 0.75, -8]} castShadow receiveShadow>
        <boxGeometry args={[6, 1.5, 3]} />
        <meshStandardMaterial color="#505050" roughness={0.7} metalness={0.3} />
      </mesh>

      <mesh position={[0, 0.75, 8]} castShadow receiveShadow>
        <boxGeometry args={[6, 1.5, 3]} />
        <meshStandardMaterial color="#505050" roughness={0.7} metalness={0.3} />
      </mesh>

      <mesh position={[-8, 0.75, 0]} castShadow receiveShadow>
        <boxGeometry args={[3, 1.5, 6]} />
        <meshStandardMaterial color="#505050" roughness={0.7} metalness={0.3} />
      </mesh>

      <mesh position={[8, 0.75, 0]} castShadow receiveShadow>
        <boxGeometry args={[3, 1.5, 6]} />
        <meshStandardMaterial color="#505050" roughness={0.7} metalness={0.3} />
      </mesh>

      {/* Elevated corner platforms */}
      <mesh position={[-10, 2, -10]} castShadow receiveShadow>
        <boxGeometry args={[4, 1, 4]} />
        <meshStandardMaterial color="#5a5a5a" roughness={0.7} metalness={0.3} />
      </mesh>

      <mesh position={[10, 2, -10]} castShadow receiveShadow>
        <boxGeometry args={[4, 1, 4]} />
        <meshStandardMaterial color="#5a5a5a" roughness={0.7} metalness={0.3} />
      </mesh>

      <mesh position={[-10, 2, 10]} castShadow receiveShadow>
        <boxGeometry args={[4, 1, 4]} />
        <meshStandardMaterial color="#5a5a5a" roughness={0.7} metalness={0.3} />
      </mesh>

      <mesh position={[10, 2, 10]} castShadow receiveShadow>
        <boxGeometry args={[4, 1, 4]} />
        <meshStandardMaterial color="#5a5a5a" roughness={0.7} metalness={0.3} />
      </mesh>

      {/* Boundary walls */}
      <mesh position={[0, 5, -15]} castShadow receiveShadow>
        <boxGeometry args={[30, 10, 1]} />
        <meshStandardMaterial color="#3a3a3a" roughness={0.8} metalness={0.2} />
      </mesh>

      <mesh position={[0, 5, 15]} castShadow receiveShadow>
        <boxGeometry args={[30, 10, 1]} />
        <meshStandardMaterial color="#3a3a3a" roughness={0.8} metalness={0.2} />
      </mesh>

      <mesh position={[-15, 5, 0]} castShadow receiveShadow>
        <boxGeometry args={[1, 10, 30]} />
        <meshStandardMaterial color="#3a3a3a" roughness={0.8} metalness={0.2} />
      </mesh>

      <mesh position={[15, 5, 0]} castShadow receiveShadow>
        <boxGeometry args={[1, 10, 30]} />
        <meshStandardMaterial color="#3a3a3a" roughness={0.8} metalness={0.2} />
      </mesh>

      {/* Accent pillars */}
      <mesh position={[-5, 1.5, -5]} castShadow receiveShadow>
        <boxGeometry args={[0.5, 3, 0.5]} />
        <meshStandardMaterial color="#6a6a6a" roughness={0.6} metalness={0.4} />
      </mesh>

      <mesh position={[5, 1.5, -5]} castShadow receiveShadow>
        <boxGeometry args={[0.5, 3, 0.5]} />
        <meshStandardMaterial color="#6a6a6a" roughness={0.6} metalness={0.4} />
      </mesh>

      <mesh position={[-5, 1.5, 5]} castShadow receiveShadow>
        <boxGeometry args={[0.5, 3, 0.5]} />
        <meshStandardMaterial color="#6a6a6a" roughness={0.6} metalness={0.4} />
      </mesh>

      <mesh position={[5, 1.5, 5]} castShadow receiveShadow>
        <boxGeometry args={[0.5, 3, 0.5]} />
        <meshStandardMaterial color="#6a6a6a" roughness={0.6} metalness={0.4} />
      </mesh>
    </group>
  );
}
