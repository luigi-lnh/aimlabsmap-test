import * as THREE from "three";

export function ArenaMap() {
  return (
    <group>
      {/* Main floor - circular arena */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <circleGeometry args={[20, 64]} />
        <meshStandardMaterial color="#3a2a2a" roughness={0.8} metalness={0.2} />
      </mesh>

      {/* Outer square floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]} receiveShadow>
        <planeGeometry args={[50, 50]} />
        <meshStandardMaterial color="#1a1a1a" roughness={0.9} metalness={0.1} />
      </mesh>

      {/* Circular grid helper */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
        <ringGeometry args={[0, 20, 32, 8]} />
        <meshBasicMaterial color="#4a3a3a" wireframe />
      </mesh>

      {/* Center raised platform */}
      <mesh position={[0, 0.25, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[3, 3, 0.5, 32]} />
        <meshStandardMaterial color="#5a4a4a" roughness={0.7} metalness={0.3} />
      </mesh>

      {/* Ring of pillars around center */}
      {Array.from({ length: 8 }).map((_, i) => {
        const angle = (i / 8) * Math.PI * 2;
        const radius = 8;
        return (
          <mesh
            key={i}
            position={[Math.cos(angle) * radius, 2, Math.sin(angle) * radius]}
            castShadow
            receiveShadow
          >
            <cylinderGeometry args={[0.4, 0.4, 4, 16]} />
            <meshStandardMaterial color="#6a5a5a" roughness={0.6} metalness={0.4} />
          </mesh>
        );
      })}

      {/* Outer ring platforms */}
      {Array.from({ length: 6 }).map((_, i) => {
        const angle = (i / 6) * Math.PI * 2;
        const radius = 14;
        return (
          <mesh
            key={i}
            position={[Math.cos(angle) * radius, 1.5, Math.sin(angle) * radius]}
            castShadow
            receiveShadow
          >
            <boxGeometry args={[3, 1, 3]} />
            <meshStandardMaterial color="#7a6a6a" roughness={0.7} metalness={0.3} />
          </mesh>
        );
      })}

      {/* Circular boundary wall */}
      <mesh position={[0, 5, 0]}>
        <cylinderGeometry args={[20, 20, 10, 32, 1, true]} />
        <meshStandardMaterial
          color="#3a2a2a"
          roughness={0.8}
          metalness={0.2}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}
