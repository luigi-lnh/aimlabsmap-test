import { useVisualSettings } from "@/lib/stores/useVisualSettings";

export function Lights() {
  const { theme } = useVisualSettings();

  // Theme-based lighting configurations
  const themes = {
    default: {
      ambient: 0.4,
      main: { intensity: 1.2, color: "#ffffff" },
      fill: { intensity: 0.6, color: "#b0c4de" },
      rim: { intensity: 0.3, color: "#8a9db5" }
    },
    neon: {
      ambient: 0.3,
      main: { intensity: 1.0, color: "#ff00ff" },
      fill: { intensity: 0.8, color: "#00ffff" },
      rim: { intensity: 0.5, color: "#ff00aa" }
    },
    sunset: {
      ambient: 0.5,
      main: { intensity: 1.5, color: "#ff6b35" },
      fill: { intensity: 0.7, color: "#ff9966" },
      rim: { intensity: 0.4, color: "#ffcc66" }
    },
    ocean: {
      ambient: 0.35,
      main: { intensity: 1.1, color: "#4a90e2" },
      fill: { intensity: 0.65, color: "#6bb6ff" },
      rim: { intensity: 0.35, color: "#a8d8ea" }
    }
  };

  const currentTheme = themes[theme];

  return (
    <>
      {/* Ambient light for base illumination */}
      <ambientLight intensity={currentTheme.ambient} />
      
      {/* Main directional light from top-front */}
      <directionalLight
        position={[5, 15, 5]}
        intensity={currentTheme.main.intensity}
        color={currentTheme.main.color}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={50}
        shadow-camera-left={-25}
        shadow-camera-right={25}
        shadow-camera-top={25}
        shadow-camera-bottom={-25}
      />
      
      {/* Secondary directional light from opposite angle for fill */}
      <directionalLight
        position={[-5, 10, -5]}
        intensity={currentTheme.fill.intensity}
        color={currentTheme.fill.color}
      />
      
      {/* Subtle rim light from behind */}
      <directionalLight
        position={[0, 5, 15]}
        intensity={currentTheme.rim.intensity}
        color={currentTheme.rim.color}
      />
    </>
  );
}
