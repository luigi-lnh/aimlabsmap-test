import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useAimTraining } from "@/lib/stores/useAimTraining";

export function Targets() {
  const { targets, addTarget, removeTarget, isActive } = useAimTraining();
  const spawnTimerRef = useRef(0);
  const positionIndexRef = useRef(0);
  const maxTargets = 6;
  const spawnInterval = 1.5;
  const targetLifetime = 5000;

  // Pre-calculate random spawn positions using useRef to persist across remounts
  const spawnPositionsRef = useRef<[number, number, number][]>();
  if (!spawnPositionsRef.current) {
    const positions: [number, number, number][] = [];
    for (let i = 0; i < 50; i++) {
      const x = (Math.random() - 0.5) * 24;
      const y = Math.random() * 6 + 2;
      const z = (Math.random() - 0.5) * 24;
      positions.push([x, y, z]);
    }
    spawnPositionsRef.current = positions;
    console.log(`Generated ${positions.length} spawn positions`);
  }

  // Clear targets when session becomes inactive
  useEffect(() => {
    if (!isActive && targets.length > 0) {
      targets.forEach(target => removeTarget(target.id));
      console.log("Cleared all targets - session inactive");
    }
  }, [isActive]);

  // Spawn targets over time
  useFrame((state, delta) => {
    if (!isActive) return;

    spawnTimerRef.current += delta;

    if (spawnTimerRef.current >= spawnInterval && targets.length < maxTargets) {
      spawnTimerRef.current = 0;
      
      const positions = spawnPositionsRef.current!;
      const position = positions[positionIndexRef.current % positions.length];
      console.log(`Spawning target ${positionIndexRef.current} at position index ${positionIndexRef.current % positions.length}`);
      positionIndexRef.current++;
      
      const newTarget = {
        id: `target-${Date.now()}-${Math.random()}`,
        position,
        spawnTime: Date.now()
      };
      
      addTarget(newTarget);
      console.log(`Spawned target at [${position[0].toFixed(1)}, ${position[1].toFixed(1)}, ${position[2].toFixed(1)}]`);
    }
  });

  // Remove targets after lifetime expires
  useEffect(() => {
    if (!isActive || targets.length === 0) return;

    const interval = setInterval(() => {
      const now = Date.now();
      targets.forEach((target) => {
        if (now - target.spawnTime > targetLifetime) {
          removeTarget(target.id);
          console.log(`Target ${target.id} expired`);
        }
      });
    }, 100);

    return () => clearInterval(interval);
  }, [targets, isActive, removeTarget]);

  return (
    <group>
      {targets.map((target) => (
        <Target key={target.id} target={target} />
      ))}
    </group>
  );
}

function Target({ target }: { target: { id: string; position: [number, number, number]; spawnTime: number } }) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  // Floating animation
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.position.y = target.position[1] + Math.sin(state.clock.elapsedTime * 2 + parseFloat(target.id.slice(-5))) * 0.2;
    }
  });

  return (
    <mesh
      ref={meshRef}
      position={target.position}
      userData={{ targetId: target.id }}
      castShadow
    >
      <sphereGeometry args={[0.5, 16, 16]} />
      <meshStandardMaterial
        color="#ff6b35"
        emissive="#ff6b35"
        emissiveIntensity={0.5}
        roughness={0.3}
        metalness={0.7}
      />
    </mesh>
  );
}
