import { useEffect, useState } from "react";
import { useAimTraining } from "@/lib/stores/useAimTraining";
import { useMapSelection, type MapType } from "@/lib/stores/useMapSelection";
import { useVisualSettings, type Theme } from "@/lib/stores/useVisualSettings";

export function HUD() {
  const { score, shots, hits, startTime, isActive, startSession, endSession, reset } = useAimTraining();
  const { currentMap, setMap } = useMapSelection();
  const { theme, setTheme, fov } = useVisualSettings();
  const [elapsedTime, setElapsedTime] = useState(0);

  useEffect(() => {
    if (!isActive || !startTime) {
      setElapsedTime(0);
      return;
    }

    const interval = setInterval(() => {
      setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
    }, 100);

    return () => clearInterval(interval);
  }, [isActive, startTime]);

  const accuracy = shots > 0 ? Math.round((hits / shots) * 100) : 0;
  const minutes = Math.floor(elapsedTime / 60);
  const seconds = elapsedTime % 60;

  return (
    <>
      {/* Crosshair */}
      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        pointerEvents: 'none',
        zIndex: 100
      }}>
        <div style={{
          position: 'relative',
          width: '20px',
          height: '20px'
        }}>
          <div style={{
            position: 'absolute',
            width: '2px',
            height: '8px',
            backgroundColor: '#00ff88',
            left: '9px',
            top: '0',
            boxShadow: '0 0 4px rgba(0, 255, 136, 0.8)'
          }} />
          <div style={{
            position: 'absolute',
            width: '2px',
            height: '8px',
            backgroundColor: '#00ff88',
            left: '9px',
            bottom: '0',
            boxShadow: '0 0 4px rgba(0, 255, 136, 0.8)'
          }} />
          <div style={{
            position: 'absolute',
            width: '8px',
            height: '2px',
            backgroundColor: '#00ff88',
            top: '9px',
            left: '0',
            boxShadow: '0 0 4px rgba(0, 255, 136, 0.8)'
          }} />
          <div style={{
            position: 'absolute',
            width: '8px',
            height: '2px',
            backgroundColor: '#00ff88',
            top: '9px',
            right: '0',
            boxShadow: '0 0 4px rgba(0, 255, 136, 0.8)'
          }} />
        </div>
      </div>

      {/* Stats HUD */}
      {isActive && (
        <div style={{
          position: 'absolute',
          top: '20px',
          left: '20px',
          fontFamily: 'Inter, sans-serif',
          color: 'white',
          fontSize: '16px',
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          padding: '15px 20px',
          borderRadius: '8px',
          pointerEvents: 'none',
          minWidth: '200px'
        }}>
          <div style={{ marginBottom: '8px', fontSize: '18px', fontWeight: 'bold', color: '#00ff88' }}>
            SCORE: {score}
          </div>
          <div style={{ marginBottom: '5px' }}>
            Accuracy: <span style={{ color: accuracy >= 70 ? '#00ff88' : accuracy >= 40 ? '#ffaa00' : '#ff4444' }}>{accuracy}%</span>
          </div>
          <div style={{ marginBottom: '5px' }}>
            Hits: {hits} / {shots}
          </div>
          <div>
            Time: {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
          </div>
        </div>
      )}

      {/* Start/End Controls */}
      <div style={{
        position: 'absolute',
        bottom: '20px',
        left: '50%',
        transform: 'translateX(-50%)',
        display: 'flex',
        gap: '10px',
        zIndex: 50
      }}>
        {!isActive ? (
          <button
            onClick={startSession}
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: '16px',
              fontWeight: 'bold',
              padding: '12px 30px',
              backgroundColor: '#00ff88',
              color: '#000',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              boxShadow: '0 0 20px rgba(0, 255, 136, 0.5)',
              transition: 'all 0.2s'
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.backgroundColor = '#00dd77';
              e.currentTarget.style.transform = 'scale(1.05)';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.backgroundColor = '#00ff88';
              e.currentTarget.style.transform = 'scale(1)';
            }}
          >
            START TRAINING
          </button>
        ) : (
          <>
            <button
              onClick={endSession}
              style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: '14px',
                padding: '10px 20px',
                backgroundColor: '#ff4444',
                color: '#fff',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer'
              }}
            >
              END SESSION
            </button>
            <button
              onClick={reset}
              style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: '14px',
                padding: '10px 20px',
                backgroundColor: '#444',
                color: '#fff',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer'
              }}
            >
              RESET
            </button>
          </>
        )}
      </div>

      {/* Instructions */}
      {!isActive && (
        <div style={{
          position: 'absolute',
          top: '20px',
          left: '50%',
          transform: 'translateX(-50%)',
          fontFamily: 'Inter, sans-serif',
          fontSize: '14px',
          color: 'white',
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          padding: '15px 25px',
          borderRadius: '8px',
          textAlign: 'center',
          pointerEvents: 'none'
        }}>
          <div style={{ marginBottom: '8px', fontSize: '16px', fontWeight: 'bold' }}>AIMLABS TRAINING</div>
          <div>Click anywhere to lock cursor and look around</div>
          <div>Click targets to destroy them and earn points</div>
        </div>
      )}

      {/* Map Selection */}
      {!isActive && (
        <div style={{
          position: 'absolute',
          top: '20px',
          right: '20px',
          fontFamily: 'Inter, sans-serif',
          zIndex: 50
        }}>
          <div style={{
            marginBottom: '10px',
            color: 'white',
            fontSize: '12px',
            fontWeight: 'bold',
            backgroundColor: 'rgba(0, 0, 0, 0.7)',
            padding: '8px 12px',
            borderRadius: '6px'
          }}>
            SELECT MAP
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '20px' }}>
            {(['classic', 'platforms', 'arena'] as MapType[]).map((mapType) => (
              <button
                key={mapType}
                onClick={() => setMap(mapType)}
                style={{
                  fontFamily: 'Inter, sans-serif',
                  fontSize: '13px',
                  fontWeight: currentMap === mapType ? 'bold' : 'normal',
                  padding: '10px 16px',
                  backgroundColor: currentMap === mapType ? '#00ff88' : 'rgba(0, 0, 0, 0.7)',
                  color: currentMap === mapType ? '#000' : '#fff',
                  border: currentMap === mapType ? 'none' : '1px solid #444',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  textTransform: 'uppercase',
                  transition: 'all 0.2s'
                }}
                onMouseOver={(e) => {
                  if (currentMap !== mapType) {
                    e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.9)';
                    e.currentTarget.style.borderColor = '#666';
                  }
                }}
                onMouseOut={(e) => {
                  if (currentMap !== mapType) {
                    e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
                    e.currentTarget.style.borderColor = '#444';
                  }
                }}
              >
                {mapType}
              </button>
            ))}
          </div>

          <div style={{
            marginBottom: '10px',
            color: 'white',
            fontSize: '12px',
            fontWeight: 'bold',
            backgroundColor: 'rgba(0, 0, 0, 0.7)',
            padding: '8px 12px',
            borderRadius: '6px'
          }}>
            THEME
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {(['default', 'neon', 'sunset', 'ocean'] as Theme[]).map((themeType) => (
              <button
                key={themeType}
                onClick={() => setTheme(themeType)}
                style={{
                  fontFamily: 'Inter, sans-serif',
                  fontSize: '13px',
                  fontWeight: theme === themeType ? 'bold' : 'normal',
                  padding: '10px 16px',
                  backgroundColor: theme === themeType ? '#00ff88' : 'rgba(0, 0, 0, 0.7)',
                  color: theme === themeType ? '#000' : '#fff',
                  border: theme === themeType ? 'none' : '1px solid #444',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  textTransform: 'uppercase',
                  transition: 'all 0.2s'
                }}
                onMouseOver={(e) => {
                  if (theme !== themeType) {
                    e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.9)';
                    e.currentTarget.style.borderColor = '#666';
                  }
                }}
                onMouseOut={(e) => {
                  if (theme !== themeType) {
                    e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
                    e.currentTarget.style.borderColor = '#444';
                  }
                }}
              >
                {themeType}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* FOV Display */}
      <div style={{
        position: 'absolute',
        bottom: '80px',
        right: '20px',
        fontFamily: 'Inter, sans-serif',
        fontSize: '12px',
        color: 'white',
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        padding: '8px 12px',
        borderRadius: '6px',
        pointerEvents: 'none'
      }}>
        FOV: {fov}° (±/- keys)
      </div>
    </>
  );
}
