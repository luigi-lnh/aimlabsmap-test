import { useEffect } from "react";
import { useThree } from "@react-three/fiber";
import * as THREE from "three";
import { useAimTraining } from "@/lib/stores/useAimTraining";

export function ClickHandler() {
  const { camera, scene, gl } = useThree();
  const { removeTarget, recordShot, recordHit, isActive } = useAimTraining();

  useEffect(() => {
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handleClick = (event: MouseEvent) => {
      if (!isActive) return;

      // Only register clicks when pointer is locked
      if (document.pointerLockElement !== gl.domElement) return;

      // Set mouse position to center of screen (where the crosshair is)
      mouse.x = 0;
      mouse.y = 0;

      // Update raycaster
      raycaster.setFromCamera(mouse, camera);

      // Check for intersections
      const intersects = raycaster.intersectObjects(scene.children, true);

      recordShot();

      for (const intersect of intersects) {
        const targetId = intersect.object.userData?.targetId;
        
        if (targetId) {
          console.log(`Hit target ${targetId}!`);
          removeTarget(targetId);
          recordHit();
          break;
        }
      }
    };

    gl.domElement.addEventListener('click', handleClick);

    return () => {
      gl.domElement.removeEventListener('click', handleClick);
    };
  }, [camera, scene, gl, removeTarget, recordShot, recordHit, isActive]);

  return null;
}
