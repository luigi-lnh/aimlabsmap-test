import { useEffect, useRef } from "react";
import { useThree, useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useVisualSettings } from "@/lib/stores/useVisualSettings";

export function CameraController() {
  const { camera, gl } = useThree();
  const { fov, increaseFov, decreaseFov } = useVisualSettings();
  const rotationRef = useRef({ yaw: 0, pitch: 0 });
  const sensitivity = 0.002;
  const maxPitch = Math.PI / 2 - 0.1; // Prevent looking straight up/down

  useEffect(() => {
    const canvas = gl.domElement;
    
    const handleMouseMove = (event: MouseEvent) => {
      // Update rotation based on mouse movement
      rotationRef.current.yaw -= event.movementX * sensitivity;
      rotationRef.current.pitch -= event.movementY * sensitivity;
      
      // Clamp pitch to prevent over-rotation
      rotationRef.current.pitch = Math.max(
        -maxPitch,
        Math.min(maxPitch, rotationRef.current.pitch)
      );
    };

    const handlePointerLockChange = () => {
      if (document.pointerLockElement === canvas) {
        console.log("Pointer locked - camera rotation active");
      } else {
        console.log("Pointer unlocked - camera rotation paused");
      }
    };

    const handleClick = () => {
      // Request pointer lock on click
      canvas.requestPointerLock();
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      // FOV controls with + and - keys
      if (event.key === '=' || event.key === '+') {
        increaseFov();
      } else if (event.key === '-' || event.key === '_') {
        decreaseFov();
      }
    };

    // Add event listeners
    canvas.addEventListener('click', handleClick);
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('pointerlockchange', handlePointerLockChange);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      canvas.removeEventListener('click', handleClick);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('pointerlockchange', handlePointerLockChange);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [gl, sensitivity, maxPitch, increaseFov, decreaseFov]);

  useFrame(() => {
    // Camera stays at fixed position (0, 5, 0)
    camera.position.set(0, 5, 0);
    
    // Update FOV
    if (camera instanceof THREE.PerspectiveCamera) {
      camera.fov = fov;
      camera.updateProjectionMatrix();
    }
    
    // Apply rotation only
    const quaternion = new THREE.Quaternion();
    const pitchQuaternion = new THREE.Quaternion();
    const yawQuaternion = new THREE.Quaternion();
    
    // Yaw rotation around Y axis
    yawQuaternion.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rotationRef.current.yaw);
    
    // Pitch rotation around X axis
    pitchQuaternion.setFromAxisAngle(new THREE.Vector3(1, 0, 0), rotationRef.current.pitch);
    
    // Combine rotations: yaw first, then pitch
    quaternion.multiplyQuaternions(yawQuaternion, pitchQuaternion);
    
    // Apply the rotation to the camera
    camera.quaternion.copy(quaternion);
  });

  return null;
}
