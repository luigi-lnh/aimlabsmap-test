import { useMapSelection } from "@/lib/stores/useMapSelection";
import { ClassicMap } from "./maps/ClassicMap";
import { PlatformsMap } from "./maps/PlatformsMap";
import { ArenaMap } from "./maps/ArenaMap";

export function MapSelector() {
  const { currentMap } = useMapSelection();

  switch (currentMap) {
    case "classic":
      return <ClassicMap />;
    case "platforms":
      return <PlatformsMap />;
    case "arena":
      return <ArenaMap />;
    default:
      return <ClassicMap />;
  }
}
